// import { PrismaClient } from "@prisma/client";

// const prisma = new PrismaClient();

// const count = await prisma.registration.count();

// console.log("Total number of registrations: ", count);


// import path from "path";
// import { __dirname } from "./src/model/pathModel.js";

// const mediaDir = path.join(__dirname, 'src/media');

// let img = path.join(__dirname, "src/media", "image.jpg")

// console.log(mediaDir);
// console.log("\n\nImage Path: ", img);

let x = [
    {
        "id": 1,
        "name": "John"
    },
    {
        "id": 2,
        "name": "Alice"
    },
    {
        "id": 3,
        "name": "Bob"
    }
]
console.log(x.length);
