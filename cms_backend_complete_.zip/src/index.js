import Express, { urlencoded } from "express";
import dotenv from "dotenv";
import cors from "cors";
import path from "path";
import UserAuthRouter from "./routes/authRoutes.js";
import coursesRouter from "./routes/coursesRoute.js";
import { logMiddleware } from "./model/logMiddleware.js";
import { handelMedia } from "./model/handelMedia.js";
import adminRouter from "./routes/adminRoute.js";

// Load environment variables from .env file
dotenv.config();

const app = Express();
const PORT = process.env.PORT || 8090;
const HOST = process.env.HOST || "localhost";

// Middleware
app.use(logMiddleware);
app.use(cors());
app.use(urlencoded({ extended: false }));
app.use(Express.json());

// Adjust the media directory path
const mediaDir = path.resolve(process.cwd(), "src/media");
app.use("/media", Express.static(mediaDir));

// Routes
app.use("/api/auth", UserAuthRouter);
app.use("/api", coursesRouter);
app.use("/api", adminRouter);

// Route to list files in the "media" directory
// app.get("/media", handelMedia);

// Start the server
app.listen(PORT, HOST, () => {
  console.log(`Server is running on port ${PORT}`);
  console.log(`API endpoint: http://${HOST}:${PORT}/`);
});
