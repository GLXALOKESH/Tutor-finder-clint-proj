import { Router } from "express";
import {
  getStudentList,
  getTeacherList,
  allCount,
  deleteStudent,
  deleteTeacher,
} from "../controllers/adminController.js";

const adminRouter = Router();


adminRouter.post("/admin/get-student-list", getStudentList);

adminRouter.post("/admin/get-teacher-list", getTeacherList);

adminRouter.post("/admin/all-count", allCount);

adminRouter.delete("/admin/delete-student", deleteStudent);

adminRouter.delete("/admin/delete-teacher", deleteTeacher);

export default adminRouter;
