// routes/authRoutes.js
import express from "express";
import {
  deleteAccount,
  getUserInfo,
  login,
  signup,
  updateProfile,
  validatePassword,
} from "../controllers/authController.js";
import { signupAdmin, loginAdmin } from "../controllers/adminAuth.js";

const router = express.Router();

router.post("/signup", signup);
router.post("/login", login);

router.post("/admin/signup", signupAdmin);
router.post("/admin/login", loginAdmin);

// profile related routes
router.post("/get-user-info", getUserInfo);
router.post("/validate-password", validatePassword);
router.post("/update-profile", updateProfile);
router.delete("/delete-account", deleteAccount);

export default router;
