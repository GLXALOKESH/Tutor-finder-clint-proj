import { Router } from "express";
import {
  buyNewCourse,
  createNewCourse,
  createNewLesson,
  deleteCourse,
  getAllCourses,
  getCourseDetails,
  getCourseLessons,
  getLesson,
  markLessonComplete,
  studentEnrollCourses,
  updateCourse,
} from "../controllers/coursesController.js";
import { multerStorage } from "../model/multerClient.js";

const coursesRouter = Router();

coursesRouter.get("/courses/all-courses", getAllCourses);

coursesRouter.post(
  "/courses/upload-new-lesson",
  multerStorage.fields([
    { name: "image1", maxCount: 1 },
    { name: "video", maxCount: 1 },
  ]),
  createNewLesson
);

coursesRouter.post("/courses/get-course/:courseId", getCourseDetails);

coursesRouter.post("/courses/new-course", createNewCourse);

coursesRouter.post("/courses/buy-new-course", buyNewCourse);

coursesRouter.post("/courses/mark-complete-lesson", markLessonComplete);

coursesRouter.post("/courses/get-course-lessons", getCourseLessons);

coursesRouter.delete("/courses/delete-course/:courseId", deleteCourse);

coursesRouter.post("/courses/update-course/", updateCourse);

coursesRouter.post("/courses/get-lesson/:lessonId", getLesson);

coursesRouter.post("/courses/student-enrolled-courses/", studentEnrollCourses);

export default coursesRouter;
