import fs from "fs";
import path from "path";
const mediaDir = path.resolve(process.cwd(), "src/media");

export const handelMedia = (req, res) => {
  fs.readdir(mediaDir, (err, files) => {
    if (err) {
      console.error("Error reading media directory:", err);
      return res.status(500).send("Error reading media directory");
    }
    res.json(files); // Send a list of files as JSON
  });
};
