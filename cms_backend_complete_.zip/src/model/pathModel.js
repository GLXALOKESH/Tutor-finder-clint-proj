import path from "path";

const __dirname = path.resolve(process.cwd());

export { __dirname };
