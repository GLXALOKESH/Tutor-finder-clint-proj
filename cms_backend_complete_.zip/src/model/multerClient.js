import multer from "multer";
import path from "path";
import { GenRandomString } from "./utils.js";
import fs from "fs";
import { __dirname } from "./pathModel.js";

// Ensure src/media directory exists
const mediaDir = path.join(__dirname, "src", "media");
if (!fs.existsSync(mediaDir)) {
  fs.mkdirSync(mediaDir, { recursive: true });
}

// Utility function to sanitize file names
const sanitizeFileName = (fileName) => {
  // Replace spaces and special characters with underscores
  return fileName.replace(/[^a-zA-Z0-9.\-]/g, "_");
};

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, mediaDir); // Save to src/media folder
  },
  filename: function (req, file, cb) {
    // Sanitize file name before saving
    const sanitizedFileName = sanitizeFileName(file.originalname);
    cb(null, Date.now() + GenRandomString(12) + "-" + sanitizedFileName);
  },
});

export const multerStorage = multer({ storage: storage });
