import jwt from "jsonwebtoken";
import dotenv from "dotenv";
import prisma from "../model/prismaClient.js";

dotenv.config();

export const getStudentList = async (req, res) => {
  try {
    const { token } = req.body;
    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);
    if (decodedToken.userType != "admin") {
      throw new Error("Unauthorized access");
    }

    const students = await prisma.student.findMany();
    return students.length > 0
      ? res.status(200).json({ status: true, students })
      : res.status(404).json({ status: false, message: "No students found" });
  } catch (error) {
    console.error(error);
    return res.status(400).json({
      status: false,
      message: "Something went wrong at backend!",
      error: error.message,
    });
  }
};

export const getTeacherList = async (req, res) => {
  try {
    const { token } = req.body;
    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);
    if (decodedToken.userType !== "admin") {
      throw new Error("Unauthorized access");
    }
    const teachers = await prisma.teacher.findMany();
    return teachers.length > 0
      ? res.status(200).json({ status: true, teachers })
      : res.status(404).json({ status: false, message: "No teachers found" });
  } catch (error) {
    console.error(error);
    return res.status(400).json({
      status: false,
      message: "Something went wrong at backend!",
      error: error.message,
    });
  }
};

export const allCount = async (req, res) => {
  try {
    const { token } = req.body;
    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);
    if (decodedToken.userType !== "admin") {
      throw new Error("Unauthorized access");
    }
    const totalUsers = await prisma.registration.count();

    const students = await prisma.student.count();
    const teachers = await prisma.teacher.count();

    const courses = await prisma.course.count();

    return res
      .status(200)
      .json({ status: true, totalUsers, students, teachers, courses });
  } catch (error) {
    console.error(error);
    return res.status(400).json({
      status: false,
      message: "Something went wrong at backend!",
      error: error.message,
    });
  }
};

export const deleteStudent = async (req, res) => {
  try {
    const { token, user_id, student_id } = req.body;
    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);
    if (decodedToken.userType !== "admin") {
      throw new Error("Unauthorized access");
    }
    const deletedStudent = await prisma.student.delete({
      where: {
        user_id: user_id,
      },
    });

    await prisma.registration.delete({
      where: {
        user_id: user_id,
      },
    });

    await prisma.login.delete({
      where: {
        user_id: user_id,
      },
    });

    await prisma.enrollment.deleteMany({
      where: {
        student_id: student_id,
      },
    });

    await prisma.studentLesson.deleteMany({
      where: {
        student_id: student_id,
      },
    });

    return res
      .status(200)
      .json({ status: true, message: "Student deleted successfully" });
  } catch (error) {
    console.error(error);
    return res.status(400).json({
      status: false,
      message: "Something went wrong at backend!",
      error: error.message,
    });
  }
};

export const deleteTeacher = async (req, res) => {
  try {
    const { token, user_id, teacher_id } = req.body;
    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);
    if (decodedToken.userType !== "admin") {
      throw new Error("Unauthorized access");
    }
    await prisma.teacher.delete({
      where: {
        user_id: user_id,
      },
    });
    await prisma.registration.delete({
      where: {
        user_id: user_id,
      },
    });
    await prisma.login.delete({
      where: {
        user_id: user_id,
      },
    });
    return res
      .status(200)
      .json({ status: true, message: "Teacher deleted successfully" });
  } catch (error) {
    console.error(error);
    return res.status(400).json({
      status: false,
      message: "Something went wrong at backend!",
      error: error.message,
    });
  }
};
