import prisma from "../model/prismaClient.js"; // Prisma client setup
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";

dotenv.config();

// Helper function to generate JWT
const generateToken = (user) => {
  return jwt.sign(
    { userId: user.user_id, email: user.email, userType: user.user_type },
    process.env.JWT_SECRET,
    {
      expiresIn: "10d",
    }
  );
};

// Signup route
export const signup = async (req, res) => {
  const {
    username,
    email,
    password,
    user_type,
    first_name,
    last_name,
    phone_number,
  } = req.body;

  // console.log(req);

  // Basic input validation
  if (
    !email ||
    !password ||
    !username ||
    !user_type ||
    !first_name ||
    !last_name ||
    !phone_number
  ) {
    return res.status(400).json({ message: "All fields are required" });
  }

  try {
    // Check if email already exists
    const existingUser = await prisma.registration.findUnique({
      where: { email },
    });
    if (existingUser) {
      return res
        .status(400)
        .json({ message: "User already exists with this email" });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create new user in Registration table
    const newUser = await prisma.registration.create({
      data: {
        username,
        email,
        password: hashedPassword,
        user_type,
      },
    });

    const saveToLogin = await prisma.login.create({
      data: {
        user_id: newUser.user_id,
        user_name: newUser.email,
        password: hashedPassword,
        user_type: newUser.user_type,
      },
    });

    // Conditionally create a Student or Teacher record
    if (user_type === "student") {
      await prisma.student.create({
        data: {
          user_id: newUser.user_id,
          first_name,
          last_name,
          phone_number,
          email,
        },
      });
    } else if (user_type === "teacher") {
      await prisma.teacher.create({
        data: {
          user_id: newUser.user_id,
          first_name,
          last_name,
          phone_number,
          email,
        },
      });
    }

    // Generate JWT token
    const token = generateToken(newUser);

    res.status(201).json({ message: "User created successfully" });
  } catch (error) {
    console.error(error); // Log the error for debugging
    res
      .status(500)
      .json({ message: "Error creating user", error: error.message });
  }
};

// Login route
export const login = async (req, res) => {
  const { email, password } = req.body;

  // Basic input validation
  if (!email || !password) {
    return res.status(400).json({ message: "Email and password are required" });
  }

  try {
    // Find user by email

    const user = await prisma.login.findUnique({ where: { user_name: email } });
    if (!user) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    // Check password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: "Invalid password" });
    }

    // Generate JWT token
    const genTokenUser = {
      user_id: user.user_id,
      email: user.user_name,
      user_type: user.user_type,
    };
    const token = generateToken(genTokenUser);

    res.status(200).json({ message: "Login successful", token });
  } catch (error) {
    console.error(error); // Log the error for debugging
    res.status(500).json({ message: "Error logging in", error: error.message });
  }
};

export const getUserInfo = async (req, res) => {
  try {
    // console.log(req.body)
    const { token } = req.body;

    const verifyToken = jwt.verify(token, process.env.JWT_SECRET);
    if (!verifyToken) {
      return res.status(401).json({ message: "Invalid Token!" });
    }

    if (verifyToken.userType == "student") {
      const UserInfo = await prisma.student.findFirst({
        where: {
          user_id: verifyToken.userId,
        },
      });

      const EnrolledCourses = await prisma.enrollment.count({
        where: {
          student_id: verifyToken.userId,
        },
      });

      return res.status(200).json({ ...UserInfo, EnrolledCourses });
    }
    if (verifyToken.userType == "teacher") {
      const UserInfo = await prisma.teacher.findFirst({
        where: {
          user_id: verifyToken.userId,
        },
      });
      return res.status(200).json({ ...UserInfo });
    }
  } catch (err) {
    return res
      .status(400)
      .json({ message: "Somthing went wrong!", error: err.message });
  }
};

export const validatePassword = async (req, res) => {
  try {
    const { token, password } = req.body;

    // Verify the JWT token
    const validateToken = jwt.verify(token, process.env.JWT_SECRET);

    // console.log(validateToken);

    if (validateToken.userType == "admin") {
      const admin = await prisma.admin.findFirst({
        where: { admin_id: validateToken.userId },
      });

      // Check if the admin exists
      if (!admin) {
        return res.status(404).json({ message: "Admin not found!" });
      }

      // Check if the provided password matches the admin's password
      const isPasswordValid = await bcrypt.compare(password, admin.password);
      console.log("Is password valid:", isPasswordValid); // Log the result of comparison

      // Check if the password is valid
      if (isPasswordValid) {
        return res.status(200).json({ message: "Password is valid" });
      } else {
        return res.status(400).json({ message: "Invalid password" });
      }
    }

    // Fetch the user from the database
    const user = await prisma.login.findFirst({
      where: { user_name: validateToken.email },
    });

    // Check if the user exists
    if (!user) {
      return res.status(404).json({ message: "User not found!" });
    }

    // Compare the provided password with the stored hashed password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    console.log("Is password valid:", isPasswordValid); // Log the result of comparison

    // Check if the password is valid
    if (isPasswordValid) {
      return res.status(200).json({ message: "Password is valid" });
    } else {
      return res.status(400).json({ message: "Invalid password" });
    }
  } catch (error) {
    // Handle token verification errors separately
    if (error instanceof jwt.TokenExpiredError) {
      return res
        .status(401)
        .json({ message: "Token has expired. Please log in again." });
    } else if (error instanceof jwt.JsonWebTokenError) {
      return res.status(400).json({ message: "Invalid token." });
    } else {
      console.error(error); // Log the error for debugging
      return res
        .status(400)
        .json({ message: "Error validating password", error: error.message });
    }
  }
};

export const updateProfile = async (req, res) => {
  try {
    const { token, data } = req.body;

    // Verify the JWT token
    const validateToken = jwt.verify(token, process.env.JWT_SECRET);

    if (!validateToken) {
      return res.status(401).json({ message: "Invalid token!" });
    }

    let updateUserData;

    // Update based on user type
    if (validateToken.userType === "student") {
      updateUserData = await prisma.student.update({
        where: { user_id: validateToken.userId },
        data,
      });
    } else if (validateToken.userType === "teacher") {
      updateUserData = await prisma.teacher.update({
        where: { user_id: validateToken.userId },
        data,
      });
    } else {
      return res.status(400).json({ message: "Invalid user type!" });
    }

    return res
      .status(200)
      .json({ message: "Profile updated successfully", data: updateUserData });
  } catch (error) {
    console.error(error); // Log the error for debugging
    if (error.code === "P2002") {
      // Unique constraint violation
      return res
        .status(400)
        .json({ message: "Email or user ID already exists." });
    }
    return res
      .status(400)
      .json({ message: "Error updating profile", error: error.message });
  }
};

export const deleteAccount = async (req, res) => {
  try {
    const { token } = req.body;

    // Verify the JWT token
    const validateToken = jwt.verify(token, process.env.JWT_SECRET);

    if (!validateToken) {
      return res.status(401).json({ message: "Invalid token!" });
    }

    // Delete user based on user type
    if (validateToken.userType === "student") {
      await prisma.student.delete({ where: { user_id: validateToken.userId } });
    } else if (validateToken.userType === "teacher") {
      await prisma.teacher.delete({ where: { user_id: validateToken.userId } });
    } else if (validateToken.userType === "admin") {
      // Only admins can delete accounts
      await prisma.admin.delete({ where: { admin_id: validateToken.userId } });
      await prisma.registration.delete({
        where: { email: validateToken.email },
      });
      return res.status(200).json({ message: "Account deleted successfully" });
    } else {
      return res.status(400).json({ message: "Invalid user type!" });
    }

    await prisma.login.delete({ where: { user_id: validateToken.userId } });
    await prisma.registration.delete({
      where: { user_id: validateToken.userId },
    });

    return res.status(200).json({ message: "Account deleted successfully" });
  } catch (error) {
    console.error(error); // Log the error for debugging
    return res
      .status(400)
      .json({ message: "Error deleting account", error: error.message });
  }
};
