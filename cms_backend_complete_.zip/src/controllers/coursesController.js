import prisma from "../model/prismaClient.js";
import dotenv from "dotenv";
import jwt from "jsonwebtoken";
import fs from "fs";
import path from "path";
import { __dirname } from "../model/pathModel.js";

// Load environment variables from.env file
dotenv.config();

const HOST = process.env.HOST || "localhost";
const PORT = process.env.PORT || "8090";

const baseURL = `http://${HOST}:${PORT}`;

export const getAllCourses = async (req, res) => {
  try {
    const courses = await prisma.course.findMany();
    res.status(200).json(courses);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const createNewLesson = async (req, res) => {
  try {
    // Parse the data if it’s a JSON string (common in FormData)
    const { token } = req.body;
    const data = JSON.parse(req.body.data);
    const { courseId, lesson_name, lesson_num, lesson_details } = data;

    // Verify the JWT token
    const verifiedToken = jwt.verify(token, process.env.JWT_SECRET);
    if (!verifiedToken) {
      return res.status(401).json({ message: "Invalid token" });
    }

    // Check if required fields are provided
    if (!courseId || !lesson_name || !lesson_num || !lesson_details) {
      return res.status(400).json({ message: "All fields are required" });
    }

    // Check if course exists
    const isValidCourse = await prisma.course.findUnique({
      where: { course_id: courseId },
    });
    if (!isValidCourse) {
      return res.status(404).json({ message: "Course not found" });
    }

    // Get uploaded file paths
    const image1 = req.files?.image1 ? req.files.image1[0].filename : null;
    const video_url = req.files?.video ? req.files.video[0].filename : null;

    // Create new lesson in the database
    const newLesson = await prisma.lesson.create({
      data: {
        lesson_name,
        lesson_num,
        lesson_details,
        image1,
        video_url,
        course_id: courseId,
      },
    });

    const baseURL = `http://${process.env.HOST}:${process.env.PORT}`;
    newLesson.image1 = image1 ? `${baseURL}/media/${image1}` : null;
    newLesson.video_url = video_url ? `${baseURL}/media/${video_url}` : null;

    res.status(201).json({
      message: "New lesson created successfully",
      lesson: newLesson,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: "Facing a problem while creating new lesson.",
      error: error.message,
    });
  }
};

export const createNewCourse = async (req, res) => {
  try {
    const { token, data } = req.body;
    const { course_name } = data;
    // Verify the JWT token
    let verifiToken = jwt.verify(token, process.env.JWT_SECRET);
    if (!verifiToken) {
      return res.status(401).json({ message: "Invalid token" });
    }
    // Check if required fields are provided
    if (!course_name) {
      return res.status(400).json({ message: "Course name is required" });
    }
    // Create new course
    const newCourse = await prisma.course.create({
      data: {
        course_name,
      },
    });
    res
      .status(201)
      .json({ message: "New course created successfully", course: newCourse });
  } catch (error) {
    res.status(400).json({
      message: "Facing a problem while creating new course.",
      error: error.message,
    });
  }
};

export const buyNewCourse = async (req, res) => {
  try {
    const { token, data } = req.body;
    const { courseId } = data;
    // Verify the JWT token
    let verifiToken = jwt.verify(token, process.env.JWT_SECRET);
    if (!verifiToken) {
      return res.status(401).json({ message: "Invalid token" });
    }
    // Check if required fields are provided
    if (!courseId) {
      return res.status(400).json({ message: "Course ID is required" });
    }
    // Check if course exists
    const isValidCourse = await prisma.course.findUnique({
      where: { course_id: courseId },
    });
    if (!isValidCourse) {
      return res.status(404).json({ message: "Course not found" });
    }

    const user_id = verifiToken.userId || null;

    if (!user_id) {
      return res.status(404).json({ message: "User not found" });
    }

    let enroll_date = new Date().toLocaleString("en-US", {
      timeZone: "Asia/Kolkata",
    });

    // Check if user has already enrolled in the course
    const isAlreadyEnrolled = await prisma.enrollment.findFirst({
      where: {
        AND: [{ course_id: courseId }, { student_id: user_id }],
      },
    });
    if (isAlreadyEnrolled) {
      return res.status(409).json({
        status: false,
        message: "User has already enrolled in the course",
      });
    }

    // Create new purchase
    const newPurchase = await prisma.enrollment.create({
      data: {
        enroll_date,
        student_id: user_id,
        course_id: courseId,
      },
    });

    res.status(201).json({
      status: true,
      message: "Course purchased successfully",
      purchase: newPurchase,
    });
  } catch (err) {
    console.log(err);
    res.status(500).json({
      message: "Facing a problem while purchasing a course.",
      error: err.message,
    });
  }
};

export const markLessonComplete = async (req, res) => {
  try {
    const { token, data } = req.body;
    const { courseId, lessonId } = data;
    // Verify the JWT token
    let verifiToken = jwt.verify(token, process.env.JWT_SECRET);
    if (!verifiToken) {
      return res.status(401).json({ message: "Invalid token" });
    }
    // Check if required fields are provided
    if (!courseId || !lessonId) {
      return res
        .status(400)
        .json({ message: "Course ID and lesson number are required" });
    }
    // Check if course and lesson exist
    const isValidCourse = await prisma.course.findUnique({
      where: { course_id: courseId },
    });
    const isValidLesson = await prisma.lesson.findUnique({
      where: { lesson_id: lessonId },
    });
    if (!isValidCourse || !isValidLesson) {
      return res.status(404).json({ message: "Course or Lesson not found" });
    }
    // Check if user has already marked the lesson as complete
    const isAlreadyMarkedComplete = await prisma.studentLesson.findFirst({
      where: {
        AND: [
          { course_id: courseId },
          { lesson_id: lessonId },
          { student_id: verifiToken.userId },
        ],
      },
    });
    if (isAlreadyMarkedComplete) {
      return res.status(409).json({
        status: false,
        message: "User has already marked the lesson as complete",
      });
    }
    // Mark the lesson as complete
    await prisma.studentLesson.create({
      data: {
        student_id: verifiToken.userId,
        lesson_id: lessonId,
        course_id: courseId,
      },
    });

    res.status(201).json({
      status: true,
      message: "Lesson marked as complete",
    });
  } catch (err) {
    console.log(err);
    return res.status(401).json({
      message: "Facing problem while mark lesson.",
      error: err.message,
    });
  }
};

export const getCourseLessons = async (req, res) => {
  try {
    const { token, courseId } = req.body;

    // Verify the JWT token
    let verifiToken = jwt.verify(token, process.env.JWT_SECRET);
    if (!verifiToken) {
      return res.status(401).json({ message: "Invalid token" });
    }

    // Ensure course ID is provided
    if (!courseId) {
      return res.status(400).json({ message: "Course ID is required" });
    }

    // Get the base URL for constructing media paths
    const baseURL = `http://${process.env.HOST}:${process.env.PORT}`;

    // Fetch course lessons from the database
    const courseLessons = await prisma.lesson.findMany({
      where: { course_id: courseId },
    });

    // Append base URL to image and video paths
    const updatedLessons = courseLessons.map((lesson) => {
      return {
        ...lesson,
        image1: lesson.image1 ? `${baseURL}/media/${lesson.image1}` : null,
        video_url: lesson.video_url
          ? `${baseURL}/media/${lesson.video_url}`
          : null,
      };
    });

    // Send the updated lessons
    res
      .status(200)
      .json({ message: "Course lessons", lessons: updatedLessons });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: "Error retrieving course lessons.",
      error: error.message,
    });
  }
};

export const deleteCourse = async (req, res) => {
  try {
    const { token } = req.body; // Access token and courseId from the body
    const { courseId } = req.params;

    if (!token || !courseId) {
      return res
        .status(400)
        .json({ message: "Token and Course ID are required" });
    }

    // Verify token
    const isValidToken = jwt.verify(token, process.env.JWT_SECRET);
    if (!isValidToken) {
      return res.status(401).json({ message: "Invalid token" });
    }

    const checkExistence = await prisma.course.findUnique({
      where: { course_id: courseId },
    });
    if (!checkExistence) {
      return res.status(404).json({ message: "Course not found" });
    }

    // Delete related records in Enrollment, Lesson, and StudentLesson
    await prisma.enrollment.deleteMany({ where: { course_id: courseId } });
    const lessons = await prisma.lesson.findMany({
      where: { course_id: courseId },
    });

    // Delete related lessons and any associated files
    for (const lesson of lessons) {
      const { image1, video_url } = lesson;

      // Delete files associated with each lesson if they exist
      if (image1) fs.unlinkSync(path.join(__dirname, "src/media", image1));
      if (video_url)
        fs.unlinkSync(path.join(__dirname, "src/media", video_url));
    }

    await prisma.lesson.deleteMany({ where: { course_id: courseId } });
    await prisma.studentLesson.deleteMany({ where: { course_id: courseId } });

    // Finally, delete the course itself
    await prisma.course.delete({ where: { course_id: courseId } });

    res
      .status(200)
      .json({ message: "Course and related data deleted successfully" });
  } catch (err) {
    console.log(err);
    return res.status(400).json({
      message: "Facing problem while deleting course.",
      error: err.message,
    });
  }
};

export const updateCourse = async (req, res) => {
  try {
    const { token, data } = req.body;
    const { courseId, course_name } = data;

    if (!token || !courseId || !course_name) {
      return res
        .status(400)
        .json({ message: "Token, Course ID, and Course Name are required" });
    }

    // Verify token
    const isValidToken = jwt.verify(token, process.env.JWT_SECRET);
    if (!isValidToken) {
      return res.status(401).json({ message: "Invalid token" });
    }

    const checkExistence = await prisma.course.findUnique({
      where: { course_id: courseId },
    });
    if (!checkExistence) {
      return res.status(404).json({ message: "Course not found" });
    }

    // Update the course name
    const course = await prisma.course.update({
      where: { course_id: courseId },
      data: { course_name },
    });

    res
      .status(200)
      .json({ message: "Course name updated successfully", course });
  } catch (err) {
    console.log(err);
    return res.status(400).json({
      message: "Facing problem while updating course name.",
      error: err.message,
    });
  }
};

export const getCourseDetails = async (req, res) => {
  try {
    const { token } = req.body;
    const { courseId } = req.params;
    const isValidToken = jwt.verify(token, process.env.JWT_SECRET);
    if (!isValidToken) {
      return res.status(401).json({ message: "Invalid token" });
    }
    // Check if required fields are provided
    if (!courseId) {
      return res.status(400).json({ message: "Course ID is required" });
    }
    // Get course details
    const courseDetails = await prisma.course.findUnique({
      where: { course_id: courseId },
    });
    if (!courseDetails) {
      return res.status(404).json({ message: "Course not found" });
    }
    res.status(200).json({ message: "Course details", course: courseDetails });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      message: "Facing problem while getting course details.",
      error: err.message,
    });
  }
};

export const getLesson = async (req, res) => {
  try {
    const { token } = req.body;
    const { lessonId } = req.params;
    if (!token || !lessonId) {
      return res
        .status(400)
        .json({ message: "Token and Lesson ID are required" });
    }
    const isValidToken = jwt.verify(token, process.env.JWT_SECRET);
    if (!isValidToken) {
      return res.status(401).json({ message: "Invalid token" });
    }
    const lesson = await prisma.lesson.findUnique({
      where: { lesson_id: lessonId },
    });
    if (!lesson) {
      return res.status(404).json({ message: "Lesson not found" });
    }

    // Append base URL to image and video paths
    lesson.image1 = lesson.image1 ? `${baseURL}/media/${lesson.image1}` : null;
    lesson.video_url = lesson.video_url
      ? `${baseURL}/media/${lesson.video_url}`
      : null;

    res.status(200).json({ message: "Lesson details", lesson });
  } catch (error) {
    console.error(error);
    return res.status(400).json({
      message: "Error retrieving lesson details",
      error: error.message,
    });
  }
};

export const studentEnrollCourses = async (req, res) => {
  try {
    const { token } = req.body;
    if (!token) {
      return res.status(400).json({ message: "Token is required" });
    }

    const verifiedToken = jwt.verify(token, process.env.JWT_SECRET);
    if (!verifiedToken) {
      return res.status(401).json({ message: "Invalid token" });
    }

    // Step 1: Fetch enrollments for the student
    const enrollments = await prisma.enrollment.findMany({
      where: { student_id: verifiedToken.userId },
    });

    // Step 2: Extract course_ids from enrollments
    const courseIds = enrollments.map((enrollment) => enrollment.course_id);

    // Step 3: Fetch course details for these courseIds
    const courses = await prisma.course.findMany({
      where: {
        course_id: { in: courseIds },
      },
      select: {
        course_id: true,
        course_name: true,
      },
    });

    res.status(200).json({
      message: "Student enrolled courses",
      courses,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: "Error fetching student enrolled courses",
      error: error.message,
    });
  }
};
